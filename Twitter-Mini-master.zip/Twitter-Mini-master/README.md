# Twitter Mini

Simple Twitter like web app

# Details of software

Backend - Nodejs,Database - Mysql and Front end adaptedfrom w3 schools.

To run on our system 

1 clone the repo

2 install mariadb and nodejs(npm)

3 run command npm i to install all packages for nodejs

4 change user name, password details of db in app.js

5 run command node app.js

6 go to url localhost:3000/ for a live demo

## For details

* [User Manual](https://github.com/Shahraaz/Twitter-Mini/blob/master/Twitter%20Mini%20User%20Manual.pdf) - Explains features of twitter
* [ER Diagrams,Schemas and FDs](https://github.com/Shahraaz/Twitter-Mini/blob/master/ER%20Diagrams%2CSchemas%20and%20FDs.pdf) - Database details

## Contributers

* **Mohammed Shahraaz Hussain** - [shahraaz](https://github.com/Shahraaz)

* **Kapil Gyanchandani** - [kapil7398](https://github.com/kapil7398)
